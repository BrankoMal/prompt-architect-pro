# GitHub Setup Guide for Prompt Architect Pro

Your project is now ready to be connected to GitHub! Follow these steps to push your code to a GitHub repository.

## Prerequisites
- A GitHub account ([Sign up here](https://github.com/join) if you don't have one)
- Git configured on your system (already done ✅)

## Step 1: Create a New Repository on GitHub

1. Go to [GitHub](https://github.com) and log in
2. Click the **"+"** icon in the top right corner
3. Select **"New repository"**
4. Fill in the details:
   - **Repository name**: `prompt-architect-pro` (or your preferred name)
   - **Description**: "High-performance prompt engineering platform with multi-modal sync"
   - **Visibility**: Choose Public or Private
   - **Important**: Do NOT initialize with README, .gitignore, or license (we already have these)
5. Click **"Create repository"**

## Step 2: Connect Your Local Repository to GitHub

After creating the repository, GitHub will show you setup instructions. Use the "push an existing repository" commands:

```bash
cd /home/ubuntu/prompt_architect_pro

# Add GitHub as the remote origin (replace USERNAME and REPO_NAME)
git remote add origin https://github.com/USERNAME/REPO_NAME.git

# Verify the remote was added
git remote -v

# Push your code to GitHub
git push -u origin master
```

**Example:**
```bash
git remote add origin https://github.com/johndoe/prompt-architect-pro.git
git push -u origin master
```

## Step 3: Authentication

When you run `git push`, you'll be prompted for authentication. You have two options:

### Option A: Personal Access Token (Recommended)
1. Go to GitHub Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Click "Generate new token (classic)"
3. Give it a name: "Prompt Architect Pro Deployment"
4. Select scopes: `repo` (full control of private repositories)
5. Click "Generate token"
6. **Copy the token immediately** (you won't be able to see it again)
7. When prompted for password during `git push`, paste this token

### Option B: SSH Keys
```bash
# Generate SSH key
ssh-keygen -t ed25519 -C "your_email@example.com"

# Copy the public key
cat ~/.ssh/id_ed25519.pub

# Add this key to GitHub:
# Settings → SSH and GPG keys → New SSH key → Paste and Save

# Update remote to use SSH
git remote set-url origin git@github.com:USERNAME/REPO_NAME.git
git push -u origin master
```

## Step 4: Verify Your Push

1. Go to your GitHub repository page
2. You should see all your files, including:
   - `nextjs_space/` directory with all source code
   - `README.md` with comprehensive documentation
   - `.gitignore` properly configured

## What's Committed?

✅ **Included:**
- All source code (TypeScript, CSS, components)
- Database schema (Prisma)
- Configuration files (package.json, tsconfig.json, etc.)
- Documentation (README.md)
- Scripts (seed.ts)
- Public assets

❌ **Excluded (via .gitignore):**
- node_modules/
- .next/ and .build/ directories
- .env files (sensitive data)
- Build artifacts
- Logs

## Future Updates

After your initial push, you can update your GitHub repository with:

```bash
# Stage your changes
git add .

# Commit with a message
git commit -m "Your commit message"

# Push to GitHub
git push
```

## Important Notes

⚠️ **Security:**
- The `.env` file is NOT committed (it's in .gitignore)
- Admin password is documented in README but should be changed in production
- Never commit sensitive credentials or API keys

📝 **Environment Variables:**
When deploying from GitHub to production, you'll need to set:
- `DATABASE_URL` (your PostgreSQL connection string)
- `NEXTAUTH_SECRET` (generate with `openssl rand -base64 32`)
- `NEXTAUTH_URL` (your production URL)

## Need Help?

- [GitHub Docs: Adding a repository](https://docs.github.com/en/get-started/importing-your-projects-to-github/importing-source-code-to-github/adding-locally-hosted-code-to-github)
- [Git Authentication](https://docs.github.com/en/authentication)
- [Git Basics](https://git-scm.com/book/en/v2/Git-Basics-Getting-Started)
