import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';
import { parse } from 'csv-parse/sync';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  // Clear existing data
  console.log('🧹 Clearing existing data...');
  await prisma.communityShowcase.deleteMany({});
  await prisma.feedbackSubmission.deleteMany({});
  await prisma.imageTool.deleteMany({});
  await prisma.videoTool.deleteMany({});
  await prisma.example.deleteMany({});
  await prisma.component.deleteMany({});
  await prisma.user.deleteMany({});

  // Create test user (admin)
  console.log('👤 Creating test user...');
  const hashedPassword = await bcrypt.hash('johndoe123', 10);
  const testUser = await prisma.user.create({
    data: {
      email: 'john@doe.com',
      password: hashedPassword,
      name: 'John Doe',
    },
  });
  console.log('✅ Test user created:', testUser.email);

  // Seed Components and Examples
  console.log('\n📦 Seeding Components and Examples...');
  const componentsPath = '/home/ubuntu/Uploads/Components_Examples.csv';
  const componentsContent = fs.readFileSync(componentsPath, 'utf-8');
  
  // Parse CSV with proper handling of multi-line fields
  const records = parse(componentsContent, {
    columns: true,
    skip_empty_lines: true,
    relax_quotes: true,
    relax_column_count: true,
  });

  let componentOrder = 1;
  for (const record of records) {
    const componentName = record['Prompt Component'];
    const componentDesc = record['Component Description'];
    const examplesText = record['Examples (50 per Component)'];

    if (!componentName || !componentDesc) continue;

    // Create component
    const component = await prisma.component.create({
      data: {
        name: componentName,
        description: componentDesc,
        order: componentOrder++,
      },
    });

    // Parse examples
    // Examples are numbered like "1. Example text (Category)"
    const exampleLines = examplesText.split('\n').filter((line: string) => line.trim());
    
    for (const line of exampleLines) {
      const trimmedLine = line.trim();
      if (!trimmedLine) continue;

      // Extract category from parentheses if present
      const categoryMatch = trimmedLine.match(/\(([^)]+)\)\s*$/);
      const category = categoryMatch ? categoryMatch[1] : null;
      
      // Remove numbering and category to get clean content
      let content = trimmedLine.replace(/^\d+\.\s*/, '').trim();
      if (category) {
        content = content.replace(/\s*\([^)]+\)\s*$/, '').trim();
      }

      await prisma.example.create({
        data: {
          componentId: component.id,
          content,
          category,
        },
      });
    }

    console.log(`  ✅ Component ${component.order}: ${componentName} (${exampleLines.length} examples)`);
  }

  // Seed Video Tools
  console.log('\n🎬 Seeding Video Tools...');
  const videoToolsPath = '/home/ubuntu/Uploads/Video_Tools.csv';
  const videoToolsContent = fs.readFileSync(videoToolsPath, 'utf-8');
  const videoToolsRecords = parse(videoToolsContent, {
    columns: true,
    skip_empty_lines: true,
    relax_quotes: true,
  });

  for (const record of videoToolsRecords) {
    const name = record['Tool Name']?.trim();
    if (!name) continue;

    await prisma.videoTool.create({
      data: {
        name,
        bestFor: record['Best For / Short Description'] || '',
        category: record['Category'] || '',
        inputType: record['Input Type'] || '',
        styleBias: record['Style Bias'] || '',
        promptStructure: record['Prompt Structure'] || '',
        recommendedTemplate: record['Recommended Template'] || '',
        imageLink: record['Image Link'] || null,
      },
    });

    console.log(`  ✅ Video Tool: ${name}`);
  }

  // Seed Image Tools
  console.log('\n🎨 Seeding Image Tools...');
  const imageToolsPath = '/home/ubuntu/Uploads/Image_Tools.csv';
  const imageToolsContent = fs.readFileSync(imageToolsPath, 'utf-8');
  const imageToolsRecords = parse(imageToolsContent, {
    columns: true,
    skip_empty_lines: true,
    relax_quotes: true,
  });

  for (const record of imageToolsRecords) {
    const name = record['Tool Name']?.trim();
    if (!name) continue;

    // Find video link by name
    const videoLinkName = record['Video Link']?.trim() || null;
    
    await prisma.imageTool.create({
      data: {
        name,
        bestFor: record['Best For / Short Description'] || '',
        category: record['Category'] || '',
        baseModel: record['Base Model'] || '',
        styleBias: record['Style Bias'] || '',
        promptStructure: record['Prompt Structure'] || '',
        recommendedTemplate: record['Recommended Template'] || '',
        costEfficiency: record['Cost Efficiency'] || null,
        videoLinkName: videoLinkName || null,
      },
    });

    console.log(`  ✅ Image Tool: ${name}${videoLinkName ? ` (linked to ${videoLinkName})` : ''}`);
  }

  // Seed Feedback Submissions (if any exist)
  console.log('\n📝 Seeding Feedback Submissions...');
  const feedbackPath = '/home/ubuntu/Uploads/Feedback_Submissions.csv';
  const feedbackContent = fs.readFileSync(feedbackPath, 'utf-8');
  const feedbackRecords = parse(feedbackContent, {
    columns: true,
    skip_empty_lines: true,
    relax_quotes: true,
  });

  let feedbackCount = 0;
  for (const record of feedbackRecords) {
    const userId = record['User_ID']?.trim();
    if (!userId) continue;

    await prisma.feedbackSubmission.create({
      data: {
        userId,
        promptUsed: record['Prompt_Used'] || '',
        imageUrl: record['Image_URL'] || null,
        rating: parseInt(record['Rating']) || 3,
        templateAdjusted: record['Template_Adjusted'] || null,
      },
    });

    feedbackCount++;
  }
  console.log(`  ✅ Feedback Submissions: ${feedbackCount} records`);

  // Create some sample community showcases
  console.log('\n🌟 Creating sample community showcases...');
  const sampleShowcases = [
    {
      promptText: 'A cyberpunk geisha standing under neon rain, cinematic lighting, 4K quality, electric purple and cyan color grading',
      rating: 5,
      imageUrl: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?w=800',
      toolUsed: 'Midjourney (V6.1)',
      approved: true,
    },
    {
      promptText: 'Professional product photography of a chrome-plated vintage motorcycle, studio lighting, highly polished reflections',
      rating: 5,
      imageUrl: 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=800',
      toolUsed: 'Adobe Firefly (Image 3)',
      approved: true,
    },
    {
      promptText: 'Hyper-realistic portrait of a crying woman, emotional depth, dramatic side lighting, 8K resolution',
      rating: 4,
      imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800',
      toolUsed: 'FLUX.1 [pro]',
      approved: true,
    },
  ];

  for (const showcase of sampleShowcases) {
    await prisma.communityShowcase.create({
      data: {
        userId: testUser.id,
        promptText: showcase.promptText,
        rating: showcase.rating,
        imageUrl: showcase.imageUrl,
        toolUsed: showcase.toolUsed,
        approved: showcase.approved,
      },
    });
  }
  console.log(`  ✅ Sample showcases: ${sampleShowcases.length} created`);

  console.log('\n✨ Database seeding completed successfully!');
  console.log('\n📊 Summary:');
  console.log(`  - Components: ${await prisma.component.count()}`);
  console.log(`  - Examples: ${await prisma.example.count()}`);
  console.log(`  - Video Tools: ${await prisma.videoTool.count()}`);
  console.log(`  - Image Tools: ${await prisma.imageTool.count()}`);
  console.log(`  - Feedback Submissions: ${await prisma.feedbackSubmission.count()}`);
  console.log(`  - Community Showcases: ${await prisma.communityShowcase.count()}`);
  console.log(`  - Users: ${await prisma.user.count()}`);
}

main()
  .catch((e) => {
    console.error('❌ Seeding error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
