'use client';

import { Navigation } from '@/components/navigation';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { useSession } from 'next-auth/react';
import { motion } from 'framer-motion';
import {
  Sparkles,
  Layers,
  Zap,
  Users,
  ArrowRight,
  CheckCircle2,
  Image,
  Video,
  TrendingUp,
} from 'lucide-react';

export default function HomePage() {
  const { data: session } = useSession() || {};

  const features = [
    {
      icon: Layers,
      title: '16-Component Constructor',
      description: 'Step-by-step prompt building with 800+ curated examples',
    },
    {
      icon: Image,
      title: 'Multi-Modal Sync',
      description: 'Seamlessly convert Image prompts to Video with intelligent mapping',
    },
    {
      icon: Zap,
      title: 'Cost Optimizer',
      description: 'Smart tool recommendations based on effectiveness analysis',
    },
    {
      icon: Users,
      title: 'Community Showcase',
      description: '5-star verified templates from the community',
    },
  ];

  const stats = [
    { label: 'Components', value: '16', icon: Layers },
    { label: 'Examples', value: '800+', icon: CheckCircle2 },
    { label: 'Image Tools', value: '33', icon: Image },
    { label: 'Video Tools', value: '14', icon: Video },
  ];

  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 sm:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-transparent to-cyan-500/10" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6">
              <Sparkles className="h-4 w-4 text-purple-400" />
              <span className="text-sm">High-Performance Prompt Engineering</span>
            </div>
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold mb-6">
              Architect Perfect Prompts
              <br />
              <span className="gradient-text">With Precision</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Master the art of prompt engineering with our comprehensive 16-component system,
              powered by 800+ examples and intelligent multi-modal conversion.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href={session ? '/builder' : '/register'}>
                <Button size="lg" className="gradient-primary text-lg gap-2 px-8">
                  {session ? 'Open Builder' : 'Get Started Free'}
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </Link>
              <Link href="/showcase">
                <Button size="lg" variant="outline" className="text-lg gap-2 px-8">
                  <Users className="h-5 w-5" />
                  Explore Showcase
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 border-y border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <stat.icon className="h-8 w-8 mx-auto mb-2 text-purple-400" />
                <div className="text-3xl sm:text-4xl font-bold gradient-text mb-1">
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-5xl font-bold mb-4">
              Everything You Need to <span className="gradient-text">Succeed</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Built with precision for prompt engineers who demand the best tools
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="glass p-8 rounded-2xl card-hover"
              >
                <div className="gradient-primary p-3 rounded-lg w-fit mb-4">
                  <feature.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground text-lg">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-purple-500/10 via-transparent to-cyan-500/10" />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="glass p-12 rounded-3xl text-center"
          >
            <TrendingUp className="h-12 w-12 mx-auto mb-6 text-purple-400" />
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Ready to Build Perfect Prompts?
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Join the community and start crafting professional-grade prompts today
            </p>
            <Link href={session ? '/builder' : '/register'}>
              <Button size="lg" className="gradient-primary text-lg gap-2 px-8">
                {session ? 'Open Builder' : 'Create Free Account'}
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-muted-foreground">
            <p>&copy; 2025 Prompt Architect Pro. Built for precision engineering.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
