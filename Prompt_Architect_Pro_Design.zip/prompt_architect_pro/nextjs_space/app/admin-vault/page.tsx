'use client';

import { useState, useEffect } from 'react';
import { Navigation } from '@/components/navigation';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { motion } from 'framer-motion';
import {
  Shield,
  Lock,
  Image,
  Video,
  Layers,
  Star,
  Check,
  X,
  Edit,
  Trash2,
} from 'lucide-react';

const ADMIN_PASSWORD = 'joxrer-dycsaR-geqmu9';

interface CommunityShowcase {
  id: string;
  promptText: string;
  rating: number;
  imageUrl: string | null;
  toolUsed: string | null;
  approved: boolean;
  createdAt: string;
  user: {
    name: string | null;
    email: string;
  };
}

export default function AdminVaultPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showcases, setShowcases] = useState<CommunityShowcase[]>([]);
  const [loading, setLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      setError('');
      fetchPendingShowcases();
    } else {
      setError('Incorrect password');
    }
  };

  const fetchPendingShowcases = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/showcases');
      const data = await res.json();
      setShowcases(data);
    } catch (error) {
      console.error('Error fetching showcases:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id: string) => {
    try {
      const res = await fetch('/api/admin/showcases', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, approved: true }),
      });

      if (res.ok) {
        fetchPendingShowcases();
      }
    } catch (error) {
      console.error('Error approving showcase:', error);
    }
  };

  const handleReject = async (id: string) => {
    try {
      const res = await fetch('/api/admin/showcases', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });

      if (res.ok) {
        fetchPendingShowcases();
      }
    } catch (error) {
      console.error('Error rejecting showcase:', error);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-transparent to-cyan-500/10" />

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md relative"
        >
          <Card className="glass p-8">
            <div className="text-center mb-8">
              <div className="gradient-primary p-3 rounded-lg w-fit mx-auto mb-4">
                <Shield className="h-8 w-8 text-white" />
              </div>
              <h1 className="text-3xl font-bold mb-2">Admin Vault</h1>
              <p className="text-muted-foreground">Enter admin password to continue</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="password" className="flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="glass border-white/20"
                />
              </div>

              {error && (
                <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                  {error}
                </div>
              )}

              <Button type="submit" className="w-full gradient-primary text-lg h-12">
                Access Admin Panel
              </Button>
            </form>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-12">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="h-8 w-8 text-purple-400" />
            <h1 className="text-4xl font-bold">
              Admin <span className="gradient-text">Vault</span>
            </h1>
          </div>
          <p className="text-muted-foreground">
            Manage tools, components, and review community submissions
          </p>
        </div>

        <Tabs defaultValue="submissions" className="space-y-6">
          <TabsList className="glass">
            <TabsTrigger value="submissions">
              <Star className="h-4 w-4 mr-2" />
              Review Submissions
            </TabsTrigger>
            <TabsTrigger value="tools">
              <Image className="h-4 w-4 mr-2" />
              Manage Tools
            </TabsTrigger>
            <TabsTrigger value="components">
              <Layers className="h-4 w-4 mr-2" />
              Manage Components
            </TabsTrigger>
          </TabsList>

          <TabsContent value="submissions">
            <Card className="glass p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">Pending Submissions</h2>
                <Button onClick={fetchPendingShowcases} variant="outline" size="sm">
                  Refresh
                </Button>
              </div>

              {loading ? (
                <div className="text-center py-12">
                  <div className="animate-spin h-8 w-8 border-4 border-purple-500 border-t-transparent rounded-full mx-auto mb-4" />
                  <p className="text-muted-foreground">Loading...</p>
                </div>
              ) : (
                <ScrollArea className="h-[600px] pr-4">
                  <div className="space-y-4">
                    {showcases?.map((showcase) => (
                      <Card
                        key={showcase.id}
                        className={`glass p-4 ${
                          showcase.approved ? 'border-green-500/30' : 'border-yellow-500/30'
                        }`}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <Badge
                              className={
                                showcase.approved
                                  ? 'bg-green-500/20 text-green-400 border-green-500/30'
                                  : 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                              }
                            >
                              {showcase.approved ? 'Approved' : 'Pending'}
                            </Badge>
                            <div className="flex items-center gap-1 mt-2">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${
                                    i < showcase.rating
                                      ? 'fill-yellow-400 text-yellow-400'
                                      : 'text-gray-600'
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            {!showcase.approved && (
                              <>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="gap-2"
                                  onClick={() => handleApprove(showcase.id)}
                                >
                                  <Check className="h-4 w-4" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="gap-2 text-red-400 border-red-500/30"
                                  onClick={() => handleReject(showcase.id)}
                                >
                                  <X className="h-4 w-4" />
                                  Reject
                                </Button>
                              </>
                            )}
                          </div>
                        </div>

                        <p className="text-sm mb-3">{showcase.promptText}</p>

                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <div>
                            Submitted by{' '}
                            {showcase.user?.name ||
                              showcase.user?.email?.split('@')[0] ||
                              'Anonymous'}
                          </div>
                          {showcase.toolUsed && (
                            <div className="text-purple-400">{showcase.toolUsed}</div>
                          )}
                        </div>
                      </Card>
                    ))}

                    {showcases?.length === 0 && (
                      <div className="text-center py-12 text-muted-foreground">
                        No submissions to review
                      </div>
                    )}
                  </div>
                </ScrollArea>
              )}
            </Card>
          </TabsContent>

          <TabsContent value="tools">
            <Card className="glass p-6">
              <h2 className="text-2xl font-bold mb-4">Manage Tools</h2>
              <p className="text-muted-foreground">
                Tool management interface - CRUD operations for Image and Video tools would be
                implemented here with similar UI patterns.
              </p>
            </Card>
          </TabsContent>

          <TabsContent value="components">
            <Card className="glass p-6">
              <h2 className="text-2xl font-bold mb-4">Manage Components</h2>
              <p className="text-muted-foreground">
                Component management interface - CRUD operations for the 16 components and their
                examples would be implemented here.
              </p>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
