'use client';

import { useState, useEffect } from 'react';
import { Navigation } from '@/components/navigation';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronLeft,
  ChevronRight,
  Copy,
  Check,
  Sparkles,
  Video,
  ArrowRight,
  TrendingUp,
  TrendingDown,
  Minus,
} from 'lucide-react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';

interface Component {
  id: string;
  name: string;
  description: string;
  order: number;
  examples: Example[];
}

interface Example {
  id: string;
  content: string;
  category: string | null;
}

interface ImageTool {
  id: string;
  name: string;
  bestFor: string;
  category: string;
  styleBias: string;
  recommendedTemplate: string;
  costEfficiency: string | null;
  videoLinkName: string | null;
}

export default function ImageBuilderPage() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(0);
  const [components, setComponents] = useState<Component[]>([]);
  const [imageTools, setImageTools] = useState<ImageTool[]>([]);
  const [selectedTool, setSelectedTool] = useState<ImageTool | null>(null);
  const [promptParts, setPromptParts] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
  }, [status, router]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [componentsRes, toolsRes] = await Promise.all([
          fetch('/api/components'),
          fetch('/api/tools/image'),
        ]);
        const componentsData = await componentsRes.json();
        const toolsData = await toolsRes.json();
        setComponents(componentsData);
        setImageTools(toolsData);
        setPromptParts(new Array(componentsData?.length || 0).fill(''));
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const getCostBadge = (tool: ImageTool) => {
    const name = tool.name?.toLowerCase() || '';
    const bestFor = tool.bestFor?.toLowerCase() || '';

    if (name.includes('free') || name.includes('craiyon') || name.includes('dreamstudio')) {
      return { label: 'Low Cost', icon: TrendingDown, color: 'bg-green-500/20 text-green-400 border-green-500/30' };
    }
    if (name.includes('pro') || name.includes('premium') || name.includes('enterprise') || 
        bestFor.includes('professional') || bestFor.includes('commercial')) {
      return { label: 'High Cost', icon: TrendingUp, color: 'bg-red-500/20 text-red-400 border-red-500/30' };
    }
    return { label: 'Medium Cost', icon: Minus, color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' };
  };

  const handleExampleClick = (content: string) => {
    const newParts = [...promptParts];
    newParts[currentStep] = content;
    setPromptParts(newParts);
  };

  const handleCustomInput = (value: string) => {
    const newParts = [...promptParts];
    newParts[currentStep] = value;
    setPromptParts(newParts);
  };

  const getFullPrompt = () => {
    return promptParts.filter(part => part?.trim()).join(', ');
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getFullPrompt());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleConvertToVideo = () => {
    const subject = promptParts[0] || '';
    const style = promptParts[3] || '';
    
    sessionStorage.setItem('convertedFromImage', 'true');
    sessionStorage.setItem('imageSubject', subject);
    sessionStorage.setItem('imageStyle', style);
    sessionStorage.setItem('originalImagePrompt', getFullPrompt());
    sessionStorage.setItem('videoLinkName', selectedTool?.videoLinkName || '');
    
    router.push('/builder/video');
  };

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin h-8 w-8 border-4 border-purple-500 border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-muted-foreground">Loading builder...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return null;
  }

  const currentComponent = components[currentStep];

  return (
    <div className="min-h-screen pb-8">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold mb-2">
            <span className="gradient-text">Image</span> Prompt Builder
          </h1>
          <p className="text-muted-foreground">
            Build your prompt step-by-step with 16 components
          </p>
        </div>

        {!selectedTool ? (
          <Card className="glass p-6 mb-8">
            <h2 className="text-xl font-bold mb-4">Select Image Generation Tool</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {imageTools?.map((tool) => {
                const costBadge = getCostBadge(tool);
                return (
                  <motion.div
                    key={tool.id}
                    whileHover={{ scale: 1.02 }}
                    className="glass-hover p-4 rounded-lg cursor-pointer"
                    onClick={() => setSelectedTool(tool)}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-sm">{tool.name}</h3>
                      <Badge className={`text-xs ${costBadge.color} border`}>
                        <costBadge.icon className="h-3 w-3 mr-1" />
                        {costBadge.label}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{tool.bestFor}</p>
                    <div className="mt-2 text-xs">
                      <span className="text-cyan-400">{tool.category}</span>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </Card>
        ) : (
          <Card className="glass p-4 mb-8">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm text-muted-foreground">Selected Tool:</span>
                <span className="font-bold ml-2">{selectedTool.name}</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedTool(null)}
              >
                Change Tool
              </Button>
            </div>
          </Card>
        )}

        {selectedTool && (
          <div className="grid lg:grid-cols-2 gap-8">
            <div>
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">
                    Step {currentStep + 1} of {components?.length || 0}
                  </span>
                  <span className="text-sm font-medium">
                    {Math.round(((currentStep + 1) / (components?.length || 1)) * 100)}% Complete
                  </span>
                </div>
                <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                  <div
                    className="h-full gradient-primary transition-all duration-300"
                    style={{ width: `${((currentStep + 1) / (components?.length || 1)) * 100}%` }}
                  />
                </div>
              </div>

              <AnimatePresence mode="wait">
                {currentComponent && (
                  <motion.div
                    key={currentStep}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card className="glass p-6 mb-6">
                      <div className="flex items-start gap-3 mb-4">
                        <div className="gradient-primary p-2 rounded-lg">
                          <Sparkles className="h-5 w-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <h2 className="text-xl font-bold mb-1">{currentComponent.name}</h2>
                          <p className="text-sm text-muted-foreground">
                            {currentComponent.description}
                          </p>
                        </div>
                      </div>

                      <div className="mb-4">
                        <label className="text-sm font-medium mb-2 block">Your Input:</label>
                        <Textarea
                          placeholder="Type your own or select from examples below..."
                          value={promptParts[currentStep] || ''}
                          onChange={(e) => handleCustomInput(e.target.value)}
                          className="glass border-white/20 min-h-[80px]"
                        />
                      </div>

                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          Examples ({currentComponent.examples?.length || 0}):
                        </label>
                        <ScrollArea className="h-[300px] pr-4">
                          <div className="space-y-2">
                            {currentComponent.examples?.map((example) => (
                              <div
                                key={example.id}
                                className="glass-hover p-3 rounded-lg cursor-pointer text-sm"
                                onClick={() => handleExampleClick(example.content)}
                              >
                                {example.content}
                                {example.category && (
                                  <Badge className="ml-2 text-xs" variant="outline">
                                    {example.category}
                                  </Badge>
                                )}
                              </div>
                            ))}
                          </div>
                        </ScrollArea>
                      </div>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                  disabled={currentStep === 0}
                  className="gap-2"
                >
                  <ChevronLeft className="h-4 w-4" />
                  Previous
                </Button>
                <Button
                  onClick={() => setCurrentStep(Math.min((components?.length || 1) - 1, currentStep + 1))}
                  disabled={currentStep === (components?.length || 1) - 1}
                  className="gradient-primary gap-2"
                >
                  Next
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="lg:sticky lg:top-24 h-fit">
              <Card className="glass p-6">
                <div className="flex items-center gap-2 mb-4">
                  <div className="h-3 w-3 rounded-full bg-red-500" />
                  <div className="h-3 w-3 rounded-full bg-yellow-500" />
                  <div className="h-3 w-3 rounded-full bg-green-500" />
                  <span className="ml-2 text-sm font-medium">Live Terminal</span>
                </div>

                <div className="terminal mb-4 max-h-[400px] overflow-auto">
                  <div className="text-cyan-400 mb-2"># Generated Prompt:</div>
                  <div className="text-green-400 whitespace-pre-wrap break-words">
                    {getFullPrompt() || '// Start building your prompt...'}
                    <span className="terminal-cursor" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Button
                    onClick={handleCopy}
                    className="w-full gap-2"
                    variant="outline"
                    disabled={!getFullPrompt()}
                  >
                    {copied ? (
                      <>
                        <Check className="h-4 w-4" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4" />
                        Copy Prompt
                      </>
                    )}
                  </Button>

                  {selectedTool?.videoLinkName && getFullPrompt() && (
                    <Button
                      onClick={handleConvertToVideo}
                      className="w-full gradient-primary gap-2"
                    >
                      <Video className="h-4 w-4" />
                      Convert to Video
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  )}
                </div>

                <div className="mt-6 pt-6 border-t border-white/10">
                  <h3 className="text-sm font-medium mb-2">Recommended Template:</h3>
                  <div className="text-xs text-muted-foreground font-mono bg-black/40 p-3 rounded">
                    {selectedTool.recommendedTemplate}
                  </div>
                </div>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
