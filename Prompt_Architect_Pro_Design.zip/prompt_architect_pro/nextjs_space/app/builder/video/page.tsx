'use client';

import { useState, useEffect } from 'react';
import { Navigation } from '@/components/navigation';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { motion } from 'framer-motion';
import { Copy, Check, Sparkles, Info } from 'lucide-react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';

interface VideoTool {
  id: string;
  name: string;
  bestFor: string;
  category: string;
  inputType: string;
  styleBias: string;
  promptStructure: string;
  recommendedTemplate: string;
}

export default function VideoBuilderPage() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [videoTools, setVideoTools] = useState<VideoTool[]>([]);
  const [selectedTool, setSelectedTool] = useState<VideoTool | null>(null);
  const [subject, setSubject] = useState('');
  const [action, setAction] = useState('');
  const [scene, setScene] = useState('');
  const [cameraMovement, setCameraMovement] = useState('');
  const [lighting, setLighting] = useState('');
  const [style, setStyle] = useState('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);
  const [convertedFromImage, setConvertedFromImage] = useState(false);
  const [originalImagePrompt, setOriginalImagePrompt] = useState('');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
  }, [status, router]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch('/api/tools/video');
        const data = await res.json();
        setVideoTools(data);

        const isConverted = sessionStorage.getItem('convertedFromImage');
        if (isConverted === 'true') {
          setConvertedFromImage(true);
          const imageSubject = sessionStorage.getItem('imageSubject') || '';
          const imageStyle = sessionStorage.getItem('imageStyle') || '';
          const videoLinkName = sessionStorage.getItem('videoLinkName') || '';
          const originalPrompt = sessionStorage.getItem('originalImagePrompt') || '';

          setSubject(imageSubject);
          setStyle(imageStyle);
          setOriginalImagePrompt(originalPrompt);

          if (videoLinkName) {
            const linkedTool = data.find((t: VideoTool) => t.name === videoLinkName);
            if (linkedTool) {
              setSelectedTool(linkedTool);
            }
          }

          sessionStorage.removeItem('convertedFromImage');
          sessionStorage.removeItem('imageSubject');
          sessionStorage.removeItem('imageStyle');
          sessionStorage.removeItem('videoLinkName');
          sessionStorage.removeItem('originalImagePrompt');
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const getFullPrompt = () => {
    const parts = [subject, action, scene, cameraMovement, lighting, style].filter(p => p?.trim());
    return parts.join(', ');
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getFullPrompt());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin h-8 w-8 border-4 border-purple-500 border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-muted-foreground">Loading builder...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return null;
  }

  return (
    <div className="min-h-screen pb-8">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold mb-2">
            <span className="gradient-text">Video</span> Prompt Builder
          </h1>
          <p className="text-muted-foreground">
            Craft cinematic video prompts with motion and camera parameters
          </p>
        </div>

        {convertedFromImage && originalImagePrompt && (
          <Card className="glass p-4 mb-8 border-cyan-500/30">
            <div className="flex items-start gap-3">
              <Info className="h-5 w-5 text-cyan-400 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-semibold mb-1">Converted from Image Prompt</h3>
                <p className="text-sm text-muted-foreground">
                  Subject and Style have been pre-filled from your image prompt:
                </p>
                <div className="text-xs font-mono bg-black/40 p-3 rounded mt-2 text-cyan-400">
                  {originalImagePrompt}
                </div>
              </div>
            </div>
          </Card>
        )}

        {!selectedTool ? (
          <Card className="glass p-6 mb-8">
            <h2 className="text-xl font-bold mb-4">Select Video Generation Tool</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {videoTools?.map((tool) => (
                <motion.div
                  key={tool.id}
                  whileHover={{ scale: 1.02 }}
                  className="glass-hover p-4 rounded-lg cursor-pointer"
                  onClick={() => setSelectedTool(tool)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-sm">{tool.name}</h3>
                    <Badge className="text-xs" variant="outline">
                      {tool.category}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">{tool.bestFor}</p>
                  <div className="text-xs text-cyan-400">{tool.inputType}</div>
                </motion.div>
              ))}
            </div>
          </Card>
        ) : (
          <Card className="glass p-4 mb-8">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm text-muted-foreground">Selected Tool:</span>
                <span className="font-bold ml-2">{selectedTool.name}</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedTool(null)}
              >
                Change Tool
              </Button>
            </div>
          </Card>
        )}

        {selectedTool && (
          <div className="grid lg:grid-cols-2 gap-8">
            <div>
              <Card className="glass p-6 mb-6">
                <div className="flex items-start gap-3 mb-6">
                  <div className="gradient-primary p-2 rounded-lg">
                    <Sparkles className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-xl font-bold mb-1">Video Parameters</h2>
                    <p className="text-sm text-muted-foreground">
                      Configure your video generation settings
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="subject">Subject</Label>
                    <Input
                      id="subject"
                      placeholder="e.g., A cyberpunk geisha"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      className="glass border-white/20 mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="action">Action / Movement</Label>
                    <Input
                      id="action"
                      placeholder="e.g., walking through neon-lit streets"
                      value={action}
                      onChange={(e) => setAction(e.target.value)}
                      className="glass border-white/20 mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="scene">Scene / Environment</Label>
                    <Input
                      id="scene"
                      placeholder="e.g., cyberpunk cityscape at night"
                      value={scene}
                      onChange={(e) => setScene(e.target.value)}
                      className="glass border-white/20 mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="camera">Camera Movement</Label>
                    <Input
                      id="camera"
                      placeholder="e.g., smooth tracking shot, dolly zoom"
                      value={cameraMovement}
                      onChange={(e) => setCameraMovement(e.target.value)}
                      className="glass border-white/20 mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="lighting">Lighting / Mood</Label>
                    <Input
                      id="lighting"
                      placeholder="e.g., dramatic rim lighting, moody atmosphere"
                      value={lighting}
                      onChange={(e) => setLighting(e.target.value)}
                      className="glass border-white/20 mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="style">Style</Label>
                    <Input
                      id="style"
                      placeholder="e.g., cinematic, 4K quality"
                      value={style}
                      onChange={(e) => setStyle(e.target.value)}
                      className="glass border-white/20 mt-1"
                    />
                  </div>
                </div>
              </Card>
            </div>

            <div className="lg:sticky lg:top-24 h-fit">
              <Card className="glass p-6">
                <div className="flex items-center gap-2 mb-4">
                  <div className="h-3 w-3 rounded-full bg-red-500" />
                  <div className="h-3 w-3 rounded-full bg-yellow-500" />
                  <div className="h-3 w-3 rounded-full bg-green-500" />
                  <span className="ml-2 text-sm font-medium">Live Terminal</span>
                </div>

                <div className="terminal mb-4 max-h-[400px] overflow-auto">
                  <div className="text-cyan-400 mb-2"># Generated Video Prompt:</div>
                  <div className="text-green-400 whitespace-pre-wrap break-words">
                    {getFullPrompt() || '// Start building your video prompt...'}
                    <span className="terminal-cursor" />
                  </div>
                </div>

                <Button
                  onClick={handleCopy}
                  className="w-full gap-2"
                  variant="outline"
                  disabled={!getFullPrompt()}
                >
                  {copied ? (
                    <>
                      <Check className="h-4 w-4" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" />
                      Copy Prompt
                    </>
                  )}
                </Button>

                <div className="mt-6 pt-6 border-t border-white/10">
                  <h3 className="text-sm font-medium mb-2">Tool Information:</h3>
                  <div className="space-y-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">Style Bias:</span>
                      <span className="ml-2 text-purple-400">{selectedTool.styleBias}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Input Type:</span>
                      <span className="ml-2 text-cyan-400">{selectedTool.inputType}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-white/10">
                  <h3 className="text-sm font-medium mb-2">Recommended Template:</h3>
                  <div className="text-xs text-muted-foreground font-mono bg-black/40 p-3 rounded">
                    {selectedTool.recommendedTemplate}
                  </div>
                </div>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
