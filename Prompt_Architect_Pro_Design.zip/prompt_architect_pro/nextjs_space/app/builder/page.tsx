'use client';

import { Navigation } from '@/components/navigation';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Image, Video, ArrowRight } from 'lucide-react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function BuilderPage() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
  }, [status, router]);

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin h-8 w-8 border-4 border-purple-500 border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return null;
  }

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            Choose Your <span className="gradient-text">Prompt Mode</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Start with Image or Video generation, with seamless multi-modal conversion
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Link href="/builder/image">
              <Card className="glass p-8 text-center card-hover cursor-pointer h-full">
                <div className="gradient-primary p-4 rounded-2xl w-fit mx-auto mb-6">
                  <Image className="h-12 w-12 text-white" />
                </div>
                <h2 className="text-2xl font-bold mb-3">Image Prompt</h2>
                <p className="text-muted-foreground mb-6">
                  Build detailed image generation prompts with 16 components and 33 supported tools
                </p>
                <div className="flex items-center justify-center gap-2 text-purple-400 font-medium">
                  Start Building
                  <ArrowRight className="h-4 w-4" />
                </div>
              </Card>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Link href="/builder/video">
              <Card className="glass p-8 text-center card-hover cursor-pointer h-full">
                <div className="gradient-primary p-4 rounded-2xl w-fit mx-auto mb-6">
                  <Video className="h-12 w-12 text-white" />
                </div>
                <h2 className="text-2xl font-bold mb-3">Video Prompt</h2>
                <p className="text-muted-foreground mb-6">
                  Craft cinematic video prompts with motion, camera, and technical parameters
                </p>
                <div className="flex items-center justify-center gap-2 text-purple-400 font-medium">
                  Start Building
                  <ArrowRight className="h-4 w-4" />
                </div>
              </Card>
            </Link>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
