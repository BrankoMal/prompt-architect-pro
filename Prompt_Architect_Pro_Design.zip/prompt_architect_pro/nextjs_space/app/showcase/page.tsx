'use client';

import { useState, useEffect } from 'react';
import { Navigation } from '@/components/navigation';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { Star, Award, Send } from 'lucide-react';
import Link from 'next/link';
import { useSession } from 'next-auth/react';
import Image from 'next/image';

interface Showcase {
  id: string;
  promptText: string;
  rating: number;
  imageUrl: string | null;
  toolUsed: string | null;
  createdAt: string;
  user: {
    name: string | null;
    email: string;
  };
}

export default function ShowcasePage() {
  const { data: session } = useSession() || {};
  const [showcases, setShowcases] = useState<Showcase[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchShowcases = async () => {
      try {
        const res = await fetch('/api/showcase');
        const data = await res.json();
        setShowcases(data);
      } catch (error) {
        console.error('Error fetching showcases:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchShowcases();
  }, []);

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }).map((_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-600'
        }`}
      />
    ));
  };

  return (
    <div className="min-h-screen pb-12">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl sm:text-5xl font-bold mb-4">
              Community <span className="gradient-text">Showcase</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              Discover 5-star verified prompts from the community
            </p>
            {session && (
              <Link href="/submit">
                <Button className="gradient-primary gap-2">
                  <Send className="h-4 w-4" />
                  Submit Your Prompt
                </Button>
              </Link>
            )}
          </motion.div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin h-8 w-8 border-4 border-purple-500 border-t-transparent rounded-full mx-auto mb-4" />
            <p className="text-muted-foreground">Loading showcases...</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {showcases?.map((showcase, index) => (
              <motion.div
                key={showcase.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="glass p-6 card-hover h-full flex flex-col">
                  {showcase.imageUrl && (
                    <div className="relative aspect-video bg-muted rounded-lg overflow-hidden mb-4">
                      <Image
                        src={showcase.imageUrl}
                        alt="Prompt result"
                        fill
                        className="object-cover"
                      />
                    </div>
                  )}

                  <div className="flex items-center gap-1 mb-3">
                    {renderStars(showcase.rating)}
                    {showcase.rating === 5 && (
                      <Badge className="ml-2 bg-yellow-500/20 text-yellow-400 border-yellow-500/30 gap-1">
                        <Award className="h-3 w-3" />
                        Verified
                      </Badge>
                    )}
                  </div>

                  <p className="text-sm mb-4 flex-1 line-clamp-4">
                    {showcase.promptText}
                  </p>

                  <div className="space-y-2 text-xs text-muted-foreground">
                    {showcase.toolUsed && (
                      <div>
                        <span className="text-purple-400">{showcase.toolUsed}</span>
                      </div>
                    )}
                    <div>
                      by {showcase.user?.name || showcase.user?.email?.split('@')[0] || 'Anonymous'}
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        )}

        {!loading && showcases?.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">No showcases yet. Be the first to submit!</p>
            {session && (
              <Link href="/submit">
                <Button className="gradient-primary gap-2">
                  <Send className="h-4 w-4" />
                  Submit Your Prompt
                </Button>
              </Link>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
