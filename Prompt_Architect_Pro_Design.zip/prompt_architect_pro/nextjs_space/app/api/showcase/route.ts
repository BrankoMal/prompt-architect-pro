import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const showcases = await prisma.communityShowcase.findMany({
      where: { approved: true },
      orderBy: [{ rating: 'desc' }, { createdAt: 'desc' }],
      include: {
        user: {
          select: {
            name: true,
            email: true,
          },
        },
      },
    });

    return NextResponse.json(showcases);
  } catch (error) {
    console.error('Error fetching showcases:', error);
    return NextResponse.json(
      { error: 'Failed to fetch showcases' },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { userId, promptText, rating, imageUrl, toolUsed } = body;

    if (!userId || !promptText || !rating) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const showcase = await prisma.communityShowcase.create({
      data: {
        userId,
        promptText,
        rating: parseInt(rating),
        imageUrl: imageUrl || null,
        toolUsed: toolUsed || null,
        approved: false,
      },
    });

    return NextResponse.json(showcase, { status: 201 });
  } catch (error) {
    console.error('Error creating showcase:', error);
    return NextResponse.json(
      { error: 'Failed to create showcase' },
      { status: 500 }
    );
  }
}
