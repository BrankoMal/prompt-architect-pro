import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const showcases = await prisma.communityShowcase.findMany({
      orderBy: [{ approved: 'asc' }, { createdAt: 'desc' }],
      include: {
        user: {
          select: {
            name: true,
            email: true,
          },
        },
      },
    });

    return NextResponse.json(showcases);
  } catch (error) {
    console.error('Error fetching all showcases:', error);
    return NextResponse.json(
      { error: 'Failed to fetch showcases' },
      { status: 500 }
    );
  }
}

export async function PATCH(req: Request) {
  try {
    const body = await req.json();
    const { id, approved } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID is required' }, { status: 400 });
    }

    const updated = await prisma.communityShowcase.update({
      where: { id },
      data: { approved: approved === true },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error('Error updating showcase:', error);
    return NextResponse.json(
      { error: 'Failed to update showcase' },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  try {
    const body = await req.json();
    const { id } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID is required' }, { status: 400 });
    }

    await prisma.communityShowcase.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting showcase:', error);
    return NextResponse.json(
      { error: 'Failed to delete showcase' },
      { status: 500 }
    );
  }
}
