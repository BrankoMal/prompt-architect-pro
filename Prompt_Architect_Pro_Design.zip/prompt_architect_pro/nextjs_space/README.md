# Prompt Architect Pro

A high-performance, data-driven prompt engineering platform with zero external API dependencies. All logic is calculated locally from database tables.

## 🚀 Overview

Prompt Architect Pro is a comprehensive NextJS application that provides professional prompt engineers with advanced tools for crafting perfect prompts for both image and video generation. The platform features a 16-component constructor, multi-modal sync capabilities, cost-effectiveness analysis, and a community showcase system.

## 🔑 Admin Access

### Admin Dashboard Location
**URL:** `/admin-vault`

### Admin Credentials
**Password:** `joxrer-dycsaR-geqmu9`

⚠️ **IMPORTANT:** This password provides access to:
- Review and approve/reject community submissions
- Manage image and video tools (CRUD operations)
- Manage components and examples (CRUD operations)

## 🗄️ Database Schema

The application uses PostgreSQL with Prisma ORM. The schema includes:

### Core Tables

#### User
- Stores user authentication data
- Fields: id, email, password (hashed with bcryptjs), name, timestamps
- Relations: One-to-many with CommunityShowcase

#### Component
- 16 prompt components (Subject, Action, Environment, Medium, Lighting, etc.)
- Fields: id, name, description, order (1-16)
- Relations: One-to-many with Example

#### Example
- 800 examples (50 per component)
- Fields: id, componentId, content, category
- Relations: Many-to-one with Component

#### VideoTool
- 14 video generation tools
- Fields: id, name, bestFor, category, inputType, styleBias, promptStructure, recommendedTemplate, imageLink
- Relations: One-to-many with ImageTool (via name reference)

#### ImageTool
- 33 image generation tools
- Fields: id, name, bestFor, category, baseModel, styleBias, promptStructure, recommendedTemplate, costEfficiency, videoLinkName
- Relations: Many-to-one with VideoTool, One-to-many with CommunityShowcase

#### CommunityShowcase
- User-submitted prompts with ratings
- Fields: id, userId, promptText, rating (1-5), imageUrl, toolUsed, approved, timestamps
- Relations: Many-to-one with User and ImageTool

#### FeedbackSubmission
- Historical feedback data from CSV import
- Fields: id, userId, promptUsed, imageUrl, rating, templateAdjusted, timestamp

## 🔄 Multi-Modal Sync Logic

### How Image → Video Conversion Works

The multi-modal sync is a **pure database lookup system** with NO AI involved:

1. **User completes Image Prompt**
   - System stores the full prompt and extracts Component 1 (Subject) and Component 4 (Style)

2. **Convert to Video Button Appears**
   - Only shown if the selected ImageTool has a `videoLinkName` field populated
   - This field contains the exact name of the corresponding VideoTool

3. **Database Lookup Process**
   ```
   ImageTool.videoLinkName → VideoTool.name (direct string match)
   ```

4. **UI Transition**
   - Navigates to `/builder/video`
   - Pre-fills "Subject" field with Component 1 from image prompt
   - Pre-fills "Style" field with Component 4 from image prompt
   - Automatically selects the linked VideoTool
   - Displays the original image prompt for reference

5. **User Completes Video Prompt**
   - Adds Motion, Camera Movement, Lighting/Mood parameters
   - Technical video parameters from VideoTool database record

### Example Flow
```
Image: "A cyberpunk geisha, neon rain, cinematic lighting, 4K"
         ↓
Subject: "A cyberpunk geisha"
Style: "cinematic lighting, 4K"
VideoTool: [Linked from ImageTool.videoLinkName]
         ↓
Video: "A cyberpunk geisha [+Motion] [+Camera] cinematic lighting, 4K"
```

## 💰 Cost-Effectiveness Algorithm

The system provides real-time cost badges (Low/Med/High) using **pattern matching on tool data**:

### Algorithm Logic

```typescript
function getCostEffectiveness(tool: ImageTool) {
  const name = tool.name.toLowerCase();
  const bestFor = tool.bestFor.toLowerCase();

  // LOW COST DETECTION
  if (
    name.includes('free') ||
    name.includes('craiyon') ||
    name.includes('dreamstudio') ||
    bestFor.includes('free')
  ) {
    return 'LOW';
  }

  // HIGH COST DETECTION
  if (
    name.includes('pro') ||
    name.includes('premium') ||
    name.includes('enterprise') ||
    name.includes('plus') ||
    bestFor.includes('professional') ||
    bestFor.includes('commercial') ||
    bestFor.includes('high-end')
  ) {
    return 'HIGH';
  }

  // DEFAULT TO MEDIUM
  return 'MEDIUM';
}
```

### Badge Display
- **🟢 Low Cost:** Green badge with TrendingDown icon
- **🟡 Medium Cost:** Yellow badge with Minus icon
- **🔴 High Cost:** Red badge with TrendingUp icon

### Smart Suggestions
When a user selects a style category (e.g., "Photography"), the system:
1. Filters ImageTools where `bestFor` matches the category
2. Ranks by cost-effectiveness (Low > Med > High)
3. Suggests the lowest-cost tool that fits the requirement

**No external APIs or manual configuration needed** - all calculated from database patterns.

## 🎨 Features

### 1. 16-Component Prompt Builder
- Step-by-step interface
- 800 curated examples (50 per component)
- Real-time "Live Terminal" preview
- Component categories: Subject, Action, Environment, Medium, Lighting, Composition, Camera, Material, Color, Mood, Time, Negative, Details, Audio, Duration, Input

### 2. Multi-Modal Support
- **Image Mode:** 33 supported tools (Midjourney, DALL-E, Stable Diffusion, etc.)
- **Video Mode:** 14 supported tools (Sora, Luma, Runway, Kling, etc.)
- Seamless conversion with intelligent field mapping

### 3. Cost Optimizer
- Real-time cost-effectiveness badges
- Smart tool recommendations by category
- Algorithm based on tool name and description patterns

### 4. Community Showcase
- Public gallery of 5-star verified prompts
- User submission system (authenticated only)
- Admin approval workflow
- "Community Verified" badges for 5-star prompts

### 5. Admin Dashboard
- Password-protected at `/admin-vault`
- Review and moderate submissions
- CRUD operations for tools and components
- Approve/reject community content

## 🎨 Design System

### Theme: "Obsidian" Dark Mode
- **Background:** #020617 (slate-950)
- **Accent Color:** Electric Purple (#A855F7) to Cyan (#06B6D4) gradient
- **Glass Morphism:** All cards and overlays
- **Typography:** Modern sans-serif with high contrast

### Visual Effects
- **Live Terminal:** Monospace font with typing animation and cyan glow
- **Framer Motion:** Smooth page transitions and component reveals
- **Hover Effects:** Shadow deepening, background shifts on interactive elements
- **Icons:** Lucide-React throughout
- **Animations:** Count-up numbers, scroll-triggered reveals, parallax effects

## 🛠️ Technology Stack

- **Framework:** Next.js 14 (App Router)
- **Database:** PostgreSQL
- **ORM:** Prisma
- **Auth:** NextAuth.js v4
- **Styling:** Tailwind CSS
- **Animations:** Framer Motion
- **Icons:** Lucide-React
- **UI Components:** Shadcn/ui

## 📁 Project Structure

```
nextjs_space/
├── app/
│   ├── api/
│   │   ├── auth/[...nextauth]/  # NextAuth routes
│   │   ├── signup/              # User registration
│   │   ├── components/          # Component data API
│   │   ├── tools/              # Tools data APIs
│   │   │   ├── image/
│   │   │   └── video/
│   │   ├── showcase/            # Community showcase API
│   │   └── admin/
│   │       └── showcases/       # Admin CRUD operations
│   ├── builder/                 # Prompt builder pages
│   │   ├── page.tsx            # Mode selection
│   │   ├── image/              # Image builder
│   │   └── video/              # Video builder
│   ├── showcase/                # Community showcase
│   ├── submit/                  # Submission form
│   ├── admin-vault/            # Admin dashboard
│   ├── login/                  # Authentication
│   ├── register/
│   └── page.tsx                # Landing page
├── components/
│   ├── navigation.tsx          # Sticky nav bar
│   ├── theme-provider.tsx
│   └── ui/                     # Shadcn components
├── lib/
│   ├── auth.ts                 # NextAuth config
│   ├── db.ts                   # Prisma client
│   └── utils.ts
├── prisma/
│   └── schema.prisma           # Database schema
├── scripts/
│   └── seed.ts                 # Database seeding
└── public/                     # Static assets
```

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- PostgreSQL database
- Yarn package manager

### Installation

1. **Clone and Install**
```bash
cd /home/ubuntu/prompt_architect_pro/nextjs_space
yarn install
```

2. **Database Setup**
```bash
# Generate Prisma client
yarn prisma generate

# Push schema to database
yarn prisma db push

# Seed with CSV data
yarn prisma db seed
```

3. **Environment Variables**
The `.env` file should contain:
```
DATABASE_URL="postgresql://..."
NEXTAUTH_SECRET="..."
NEXTAUTH_URL="http://localhost:3000"
```

4. **Run Development Server**
```bash
yarn dev
```

Visit `http://localhost:3000`

### Test Account
- **Email:** john@doe.com
- **Password:** johndoe123
- **Role:** Standard user with admin privileges

## 📊 Data Import

The application automatically imports data from 4 CSV files:

1. **Components_Examples.csv**
   - 16 components with 50 examples each
   - Total: 800 examples

2. **Video_Tools.csv**
   - 14 video generation tools
   - Parameters: name, bestFor, category, inputType, styleBias, templates

3. **Image_Tools.csv**
   - 33 image generation tools
   - Parameters: name, bestFor, category, baseModel, styleBias, templates, costEfficiency, videoLink

4. **Feedback_Submissions.csv**
   - Historical feedback data (imported as-is)

All imports are handled by `/scripts/seed.ts` using CSV parsing.

## 🔐 Security

### Password Hashing
- User passwords: bcryptjs with salt rounds = 10
- Admin password: Hardcoded (simple auth, not database-backed)

### Protected Routes
- `/builder/*` - Requires user authentication
- `/submit` - Requires user authentication
- `/admin-vault` - Requires admin password

### Session Management
- JWT strategy with NextAuth
- Secure HTTP-only cookies
- Session persistence across reloads

## 🎯 Key Pages

| Route | Description | Authentication |
|-------|-------------|----------------|
| `/` | Landing page with features overview | Public |
| `/login` | User login | Public |
| `/register` | User registration | Public |
| `/builder` | Prompt mode selection | Required |
| `/builder/image` | Image prompt builder | Required |
| `/builder/video` | Video prompt builder | Required |
| `/showcase` | Community showcase gallery | Public |
| `/submit` | Submit prompt for review | Required |
| `/admin-vault` | Admin dashboard | Admin Password |

## 📈 Performance

- **Zero External APIs:** All data is local
- **Server-Side Rendering:** Fast initial load
- **Database Indexes:** Optimized queries
- **Client-Side State:** Minimal re-fetches
- **Responsive Design:** Mobile-first approach

## 🔧 Maintenance

### Adding New Tools
1. Access `/admin-vault` with admin password
2. Navigate to "Manage Tools" tab
3. Add/Edit/Delete tools with inline forms
4. Changes immediately reflected in builders

### Reviewing Submissions
1. Access `/admin-vault`
2. Navigate to "Review Submissions" tab
3. View all pending and approved submissions
4. Approve (makes public) or Reject (deletes) submissions

### Updating Components
1. Access `/admin-vault`
2. Navigate to "Manage Components" tab
3. Edit component descriptions or examples
4. Changes propagate to all builders

## 📝 Notes

- **Multi-Modal Sync:** Pure database lookup, no AI/LLM involved
- **Cost Algorithm:** Pattern-based, no manual configuration
- **Admin Password:** Documented here and should NOT be exposed in UI
- **Test Account:** Pre-seeded for testing and demonstrations
- **Community Showcase:** Requires admin approval before public display

## 📞 Support

For technical questions or issues:
1. Check this README
2. Review database schema in `prisma/schema.prisma`
3. Inspect API routes in `app/api/`
4. Check seed script for data import logic

## 🎉 Success Criteria

✅ All 4 CSV files imported successfully  
✅ 16-component builder operational  
✅ Multi-modal sync with database lookups  
✅ Cost-effectiveness badges display correctly  
✅ Community showcase shows verified templates  
✅ Admin dashboard allows CRUD operations  
✅ Beautiful Obsidian theme applied throughout  
✅ Complete documentation with admin password  

---

**Built with precision for prompt engineers who demand the best tools.**
